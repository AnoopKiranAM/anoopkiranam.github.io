 // main document ready function to check if dom is loaded fully or not
  $( document ).ready(function() {
	$('.loader').hide();
	$(".about1").hide();
	$(".about2").hide();

    var myFacebookToken = 'EAACEdEose0cBAAVwATAYbK2FxAFIWfb9slkADMQXXIPU2ZBrvn6ZANOmbvWAeNLuP3xu1JwKqohZCJUAKRgjw4aSkEHPopFXxKYkjqyp9sV6v43ah2d5o5RRKZAFtUZBwShuUZAbvxf6RaFhHx08bVxOQ2mcrn4hcQePdehZBRG9zGfJEoo7afdTpoRHEaU8WxwUHW3Ux6kCwZDZD';



   		 	$("#facebookBtn").on('click',getAboutInfo);
   		 	 $('.data').removeData();
      		$("#postsBtn").on('click',getPostsInfo);
 $('.data').removeData();


function getPostsInfo(){

 
    $(".about1").hide();
    $(".about2").show();
    



        $.ajax('https://graph.facebook.com/v2.11/me?fields=name,education,friends{name},email,about,posts,hometown,birthday&access_token='+myFacebookToken,{

                success : function(response){
					$("#id").text(response.posts.data[1].id);
					$("#msgField").text(response.posts.data[1].message);
					$("#storyField").text(response.posts.data[1].story);
					$("#createdField").text(response.posts.data[1].created_time);
					
					$("#id2").text(response.posts.data[2].id);
					$("#msgField2").text(response.posts.data[2].message);
					$("#storyField2").text(response.posts.data[2].story);
					$("#createdField2").text(response.posts.data[2].created_time);
					
					$("#id3").text(response.posts.data[3].id);
					$("#msgField3").text(response.posts.data[3].message);
					$("#storyField3").text(response.posts.data[3].story);
					$("#createdField3").text(response.posts.data[3].created_time);
                },
                error : function(request,errorType,errorMessage){

                    console.log(request);
                    console.log(errorType);
                    alert(errorMessage);
                },
                 

                 beforeSend : function(){

                    $('.loader').show();

                },

                complete : function(){

                   $('.loader').hide();
                  

                }
            }//end argument list 



        );// end ajax call 


    }// end get facebook info


    function getAboutInfo()
    {
    		
    		$(".about2").hide();
    		$(".about1").show();
    		
        $.ajax('https://graph.facebook.com/v2.11/me?fields=name,education,favorite_athletes,friends{name},email,about,posts,hometown,birthday&access_token='+myFacebookToken,{

                success : function(response){
                  
                    $("#nameField").text(response.name);
                   	$("#emailField").text(response.email);
				   	$("#birthdayField").text(response.birthday);
				  	$("#idField").text(response.id);
					$("#hometownField").text(response.hometown.name);
					
				    $("#aboutField").text(response.about);
					$("#1").text(response.friends.data[0].name);
					$("#2").text(response.friends.data[1].name);
					$("#3").text(response.friends.data[2].name);
					$("#4").text(response.friends.data[3].name);
					$("#5").text(response.friends.data[4].name);
					$("#6").text(response.friends.data[1].id);
					$("#7").text(response.friends.data[2].id);
					$("#8").text(response.friends.data[3].id);
					$("#9").text(response.friends.data[4].id);
					$("#10").text(response.friends.data[5].id);
					$("#schoolField").text(response.education[1].school.name);
					$("#collegeField").text(response.education[4].school.name);
					
					
					$("#a1").text(response.favorite_athletes[0].name);
					$("#a2").text(response.favorite_athletes[1].name);
					$("#a3").text(response.favorite_athletes[2].name);
					$("#a4").text(response.favorite_athletes[4].name);
					$("#a5").text(response.favorite_athletes[9].name);
					$("#a6").text(response.favorite_athletes[8].name);
					//$("#postsField").append(response.posts.data[0].id);
                },
                error : function(request,errorType,errorMessage){

                    console.log(request);
                    console.log(errorType);
                    alert(errorMessage);
                },
               // in ms
                 
				beforeSend : function(){

                    $('.loader').show();

                },
                complete : function(){
                   $('.loader').hide();
                    
                }
            }//end argument list 
       	  );// end ajax call 
    }// end get facebook info

});



  
  



